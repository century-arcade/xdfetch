# 20261030-130000-www.zip

1 files from 1 outlets, fetched 2026-10-30 (UTC) by othertool 0.1.0. `MANIFEST.tsv` has each file's URL, sha256 and fetch time.

## Where the files came from

- **example.daily** (1 file, 2026-10-28), from https://example.com/daily/.
  Each file is fetched from `https://example.com/feed/ex%y%m%d.xml` (strftime fields filled with the puzzle's date), saved as served. A made-up daily feed. Named exYYMMDD.xml.

## How they were converted

Not converted inside this archive. othertool's `convert` step reads the archive and writes `.xd` files; the converter used is chosen from each file's content. The version of othertool that converted a file is recorded in the commit that added it.

## Known issues

None recorded at fetch time.
